"""
ko custom locale file.
"""
from __future__ import annotations


translations = {
    # Relative time
    "after": "{0} 후",
    "before": "{0} 전",
    # Date formats
    "date_formats": {
        "LTS": "A h시 m분 s초",
        "LT": "A h시 m분",
        "LLLL": "YYYY년 MMMM D일 dddd A h시 m분",
        "LLL": "YYYY년 MMMM D일 A h시 m분",
        "LL": "YYYY년 MMMM D일",
        "L": "YYYY.MM.DD",
    },
}
